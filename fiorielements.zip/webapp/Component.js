sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("student00.sap.training.fiorielements.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});