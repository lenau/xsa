sap.ui.define([
	"student00/sap/training/startnavigation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});