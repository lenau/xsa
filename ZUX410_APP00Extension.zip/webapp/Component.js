jQuery.sap.declare("student00.sap.training.dynamicpage.ZUX410_APP00Extension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "student00.sap.training.dynamicpage",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/ZUX410_APP00"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.student00.sap.training.dynamicpage.Component.extend("student00.sap.training.dynamicpage.ZUX410_APP00Extension.Component", {
	metadata: {
		manifest: "json"
	}
});