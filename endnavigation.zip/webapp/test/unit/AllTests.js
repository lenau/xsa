sap.ui.define([
	"student00/sap/training/endnavigation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});