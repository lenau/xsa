sap.ui.define([
	"student00/sap/training/valuehelp/test/unit/controller/Main.controller"
], function () {
	"use strict";
});