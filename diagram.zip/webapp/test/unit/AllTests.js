sap.ui.define([
	"student00/sap/training/diagram/test/unit/controller/Main.controller"
], function () {
	"use strict";
});